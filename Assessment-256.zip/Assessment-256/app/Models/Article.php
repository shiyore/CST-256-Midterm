<?php
namespace App\Models;

class Article
{
    //Private fields that store the article data
    private $title, $content, $author, $tags;
    
    //basic constructor that just sets the globals
    public function __construct (string $title, string $content, String $author, String $tags) {
        $this->title = $title;
        $this->content = $content;
        $this->author = $author;
        $this->tags = $tags;
    }
    
    
    //PUBLIC GETTERS AND SETTERS
    public function getTitle () {
        return $this->title;
    }
    public function setTitle (string $title) {
        $this->title = $title;
    }
    
    public function getContent () {
        return $this->content;
    }
    
    public function setContent (string $content) {
        $this->content = $content;
    }
    
    public function setAuthor (String $author) {
        $this->author = $author;
    }
    public function getAuthor () {
        return $this->author;
    }
    
    public function setTags (String $tags) {
        $this->tags = $tags;
    }
    
    public function getTags () {
        return $this->tags;
    }
}

?>