<?php
namespace App\Services;

use App\Models\Article;
use Illuminate\Support\Str;

class ArticleBusinessService
{
    //simply evaluates whether the tags contains the string CST-256. returns true or false if it does or does not.
    public function verify(Article $article){
        return Str::contains($article->getTags(),"CST-256");
    }
}

?>