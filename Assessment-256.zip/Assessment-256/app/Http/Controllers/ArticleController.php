<?php
namespace App\Http\Controllers;
/**
 * Written by Aiden Yoshioka 02/14/21
 * 
 * Bare bones controller for the purpose of the midterm 
 */
use App;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Article;
use App\Services\ArticleBusinessService;

class ArticleController extends Controller
{
    public function formToModel(Request $request){
        $article = new Article($request->get('article_title'),$request->get('article_content'),$request->get('article_author'),$request->get('article_tags'));
        
        $service = new ArticleBusinessService();
        
        if($service->verify($article))
            return view('ViewArticle' , ['article' => $article]);
        else
            return view('failedsubmission');

    }
}
