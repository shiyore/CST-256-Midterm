<html>
<!-- 
    Written by Aiden Yoshioka
    
    This is just the basic template for all the articles to be output. If I find time, I will be encorporating parsedown to format the articles to look better.
 -->
<head>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
</head>
<body>
	<p><h1 class="display-1 text-center">{{$article->getTitle()}}</h1></p>
	<hr/>
	<br/>
	<p class="text-left font-weight-normal">{{$article->getContent()}}</p>
</body>
</html>