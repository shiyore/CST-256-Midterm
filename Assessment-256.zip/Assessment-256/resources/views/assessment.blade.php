<html>
<!-- 
    Written by Aiden Yoshioka
    
    This is just a simple form for the midterm
 -->
<head>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
</head>
<body>
		<form action="articleprocessing" method="post">
			{{csrf_field()}}
          <div class="form-group">
            <label for="article_title">Article Title</label>
            <input type="text" class="form-control" name="article_title" id="article_title" placeholder="Article Title">
          </div>
          <br>
          <div class="form-group">
            <label for="article_content">Article Content</label>
            <textarea class="form-control" name="article_content" id="article_content" rows="3"></textarea>
          </div>
          <br>
          <div class="form-group">
            <label for="article_author">Article Author</label>
            <input type="text" class="form-control" name="article_author" id="article_author" placeholder="Author Name">
          </div>
          <br>
          <div class="form-group">
            <label for="article_tags">Article Tags/Categories</label>
            <input type="text" class="form-control" name="article_tags" id="article_tags" placeholder="Tags/Categories">
          </div>
          <button class="btn btn-lg btn-success" type="submit">Submit</button>
        </form>

</body>
</html>